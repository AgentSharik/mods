---
navigation:
  title: Наковальня из сплава Eclipse
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 4
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:eclipse_alloy_anvil
---

# Наковальня из сплава Eclipse

Наковальня, которая чинит предметы с помощью энергии Forge (FE), как и <ItemLink id="justdynathings:celestigem_anvil"/>
Кроме того, при добавлении [охладителя](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/fluid/anvils/eclipsealloy_repair.json) починка считается как `эффективность охладителя / 100 × весь урон`; предмет может получить больше 1000 за тик либо будет починен полностью

<BlockImage id="justdynathings:eclipse_alloy_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:eclipse_alloy_anvil" />

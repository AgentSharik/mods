---
navigation:
  title: Солнечная панель из Blazegold
  icon: "justdynathings:blazegold_solar_panel"
  position: 2
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:blazegold_solar_panel
---

# Солнечная панель из Blazegold

Солнечная панель, вырабатывающая энергию Forge

Макс. выработка FE по умолчанию: **960**

**Условия по умолчанию:**

- Измерение = Нижний мир

<BlockImage id="justdynathings:blazegold_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:blazegold_solar_panel" />

_Примечание: всё меняется в конфигах, так что этим цифрам вообще не верьте!_

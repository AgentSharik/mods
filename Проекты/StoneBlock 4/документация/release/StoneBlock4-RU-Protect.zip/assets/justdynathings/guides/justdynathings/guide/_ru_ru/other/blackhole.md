---
navigation:
  title: Чёрная дыра
  icon: "justdynathings:blackhole"
  position: 5
  parent: justdynathings:other.md
item_ids:
  - justdynathings:blackhole
---

# Чёрная дыра

Более известна как _универсальная мусорка_

Её можно выключить — и тогда в этом дешёвом корпусе поместится невообразимое количество энергии или жидкостей!

<BlockImage id="justdynathings:blackhole" scale="4.0"/>

<Recipe id="justdynathings:blackhole" />

---
navigation:
  title: Тикер
  icon: "justdynathings:ticker"
  position: 8
  parent: justdynathings:other.md
item_ids:
  - justdynathings:ticker
---

# Время относительно

Расходует временную жидкость и энергию, чтобы ускорять блок на подсвеченной грани (по умолчанию в 16 раз)

<BlockImage id="justdynathings:ticker" scale="4.0"/>

<Recipe id="justdynathings:ticker" />

---
navigation:
  title: Солнечные панели
  icon: "justdynathings:blazegold_solar_panel"
  position: 4
---

# Сила Солнца

Новый набор генераторов, которые вырабатывают энергию Forge в зависимости от условий вокруг

<SubPages />

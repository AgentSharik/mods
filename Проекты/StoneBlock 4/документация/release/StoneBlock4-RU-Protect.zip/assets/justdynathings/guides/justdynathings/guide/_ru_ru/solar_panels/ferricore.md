---
navigation:
  title: Солнечная панель из Ferricore
  icon: "justdynathings:ferricore_solar_panel"
  position: 1
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:ferricore_solar_panel
---

# Солнечная панель из Ferricore

Солнечная панель, вырабатывающая энергию Forge

Макс. выработка FE по умолчанию: **240**

**Условия по умолчанию:**

- Измерение = Верхний мир
- Видит небо = да
- Дневное время = да

<BlockImage id="justdynathings:ferricore_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:ferricore_solar_panel" />

_Примечание: всё меняется в конфигах, так что этим цифрам вообще не верьте!_

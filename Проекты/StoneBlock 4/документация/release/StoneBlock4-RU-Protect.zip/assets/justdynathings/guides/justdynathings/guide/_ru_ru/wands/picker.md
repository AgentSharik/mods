---
navigation:
  title: Жезл захвата
  icon: "justdynathings:picker_wand"
  position: 2
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:picker_wand
---

# Жезл захвата

Жезл, который подбирает блок и ставит его туда, куда вы хотите

<ItemImage id="justdynathings:picker_wand" scale="4.0"/>

<Recipe id="justdynathings:picker_wand" />

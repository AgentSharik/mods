---
navigation:
  title: Продвинутый световой жезл
  icon: "justdynathings:advanced_light_wand"
  position: 6
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_light_wand
---

# Да будет свет! Часть 2

Работает так же, как <ItemLink id="justdynathings:light_wand"/>, но расходует FE при каждом использовании

<ItemImage id="justdynathings:advanced_light_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_light_wand" />

---
navigation:
  title: Термогенератор
  icon: "justdynathings:thermo_generator"
  position: 6
  parent: justdynathings:other.md
item_ids:
  - justdynathings:thermo_generator
---

# Сила земли

Новый генератор, который вырабатывает энергию Forge из блоков-источников тепла и жидкого охладителя

<BlockImage id="justdynathings:thermo_generator" scale="4.0" p:facing="down" p:active="true"/>

<Recipe id="justdynathings:thermo_generator" />

## Как это считается

FE gen = 125 x CoolantEfficiency x HeatEfficiency

MB cost = 125 / CoolantEfficiency

_вероятно, в будущем это упростят_

---
navigation:
  title: Наковальня из Celestigem
  icon: "justdynathings:celestigem_anvil"
  position: 3
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:celestigem_anvil
---

# Наковальня из Celestigem

Наковальня, которая чинит предметы с помощью энергии Forge (FE)

<BlockImage id="justdynathings:celestigem_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:celestigem_anvil" />

---
navigation:
  title: Перековщик
  icon: "justdynathings:reforger"
  position: 2
  parent: justdynathings:other.md
item_ids:
  - justdynathings:reforger
---

# Перековщик

Мощная машина: превращает входной блок, поставленный к _красной грани_, в _выходной блок_, расходуя _катализатор_

<BlockImage id="justdynathings:reforger" p:facing="up" p:active="true" scale="4.0"/>

<Recipe id="justdynathings:reforger" />

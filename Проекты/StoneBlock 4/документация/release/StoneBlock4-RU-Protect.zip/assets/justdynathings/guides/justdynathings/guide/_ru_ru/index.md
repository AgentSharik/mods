---
navigation:
  title: Введение
  icon: "minecraft:redstone"
  position: 0
---

# Just Dyna Things

Аддон к JustDireThings, добавляющий новые вещи

<SubPages />

---
navigation:
  title: Наковальня из Blazegold
  icon: "justdynathings:blazegold_anvil"
  position: 2
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:blazegold_anvil
---

# Наковальня из Blazegold

Наковальня, которая чинит предметы [горячими жидкостями](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/fluid/anvils/blazegold_repair.json)

<BlockImage id="justdynathings:blazegold_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:blazegold_anvil" />

---
navigation:
  title: Новый Goo
  icon: "justdirethings:gooblock_tier1"
  position: 3
---

# Goo

Новые уровни Goo!

<CategoryIndex category="goo"></CategoryIndex>

_Было бы неплохо, если бы Goo любого уровня работал по той же логике, что и <ItemLink id="justdynathings:energized_goo"/> — так я это и сделал!
-DevDyna_

<CategoryIndex category="energy_goo"></CategoryIndex>

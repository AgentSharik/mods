---
navigation:
  title: Творческий Goo
  icon: "justdynathings:creative_goo"
  parent: goo.md
  position: 99
categories:
  - goo
item_ids:
  - justdynathings:creative_goo
---

# Творческий Goo

Простой Goo, который не может умереть
Его можно переключать любым ключом

Уровень: **МАКС**

<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="false"/> 
<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="true" />

<RecipeFor id="justdynathings:creative_goo" />

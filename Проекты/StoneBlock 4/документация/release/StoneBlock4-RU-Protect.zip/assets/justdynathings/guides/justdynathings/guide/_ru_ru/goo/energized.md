---
navigation:
  title: Энергетический Goo
  icon: "justdynathings:energized_goo"
  parent: goo.md
  position: 1
categories:
  - goo
item_ids:
  - justdynathings:energized_goo
---

# Энергетический Goo

Новый Goo, которому нужна **энергия Forge**, чтобы оставаться живым

Уровень: **5**

<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="false"/>
<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="true"/>

<RecipeFor id="justdynathings:energized_goo" />

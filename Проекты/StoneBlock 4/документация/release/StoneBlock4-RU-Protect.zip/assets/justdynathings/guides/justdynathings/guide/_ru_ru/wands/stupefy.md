---
navigation:
  title: Временной жезл оглушения
  icon: "justdynathings:temporal_stupefy_wand"
  position: 4
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:temporal_stupefy_wand
---

# Временной жезл оглушения

Жезл, который убирает сущности временного жезла и накладывает короткое оглушение

<ItemImage id="justdynathings:temporal_stupefy_wand" scale="4.0"/>

<Recipe id="justdynathings:temporal_stupefy_wand" />

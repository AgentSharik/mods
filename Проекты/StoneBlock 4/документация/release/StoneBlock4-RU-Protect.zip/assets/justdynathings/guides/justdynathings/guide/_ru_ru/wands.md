---
navigation:
  title: Новые жезлы
  icon: "justdynathings:swapper_wand"
  position: 5
---

# Новые жезлы

Новые предметы с особыми эффектами

<CategoryIndex category="wands"></CategoryIndex>

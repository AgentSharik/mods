---
navigation:
  title: Новые наковальни
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 2
---

# Новые наковальни

Особые наковальни, позволяющие чинить вещи без опыта

<SubPages />

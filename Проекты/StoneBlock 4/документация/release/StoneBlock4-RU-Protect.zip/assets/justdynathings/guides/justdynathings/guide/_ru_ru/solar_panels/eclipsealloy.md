---
navigation:
  title: Солнечная панель из сплава Eclipse
  icon: "justdynathings:eclipse_alloy_solar_panel"
  position: 4
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:eclipse_alloy_solar_panel
---

# Солнечная панель из сплава Eclipse

Солнечная панель, вырабатывающая энергию Forge

Макс. выработка FE по умолчанию: **11520**

**Условия по умолчанию:**

- Чем больше панелей стоит рядом, тем больше выработка
- Высокий или низкий уровень Y повышает множитель, средний уровень Y — понижает

<BlockImage id="justdynathings:eclipse_alloy_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:eclipse_alloy_solar_panel" />

_Примечание: всё меняется в конфигах, так что этим цифрам вообще не верьте!_

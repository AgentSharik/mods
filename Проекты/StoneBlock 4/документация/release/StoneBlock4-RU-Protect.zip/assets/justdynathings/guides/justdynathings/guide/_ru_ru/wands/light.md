---
navigation:
  title: Световой жезл
  icon: "justdynathings:light_wand"
  position: 5
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:light_wand
---

# Да будет свет!

Новый жезл, который ставит и убирает блоки света
Также он накладывает эффект свечения на сущность, на которую вы смотрите

При использовании расходует прочность

<ItemImage id="justdynathings:light_wand" scale="4.0"/>

<Recipe id="justdynathings:light_wand" />

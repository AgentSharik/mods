---
navigation:
  title: Наковальня из Ferricore
  icon: "justdynathings:ferricore_anvil"
  position: 1
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:ferricore_anvil
---

# Наковальня из Ferricore

Наковальня, которая чинит инструменты с помощью [катализаторов](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/item/anvils/ferricore_repair.json)

<BlockImage id="justdynathings:ferricore_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:ferricore_anvil" />

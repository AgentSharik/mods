---
navigation:
  title: Солнечная панель из Celestigem
  icon: "justdynathings:celestigem_solar_panel"
  position: 3
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:celestigem_solar_panel
---

# Солнечная панель из Celestigem

Солнечная панель, вырабатывающая энергию Forge

Макс. выработка FE по умолчанию: **3840**

**Условия по умолчанию:**

- Видит небо = да
- Чем больше панелей стоит рядом, тем больше выработка

<BlockImage id="justdynathings:celestigem_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:celestigem_solar_panel" />

_Примечание: всё меняется в конфигах, так что этим цифрам вообще не верьте!_

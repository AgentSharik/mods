---
navigation:
  title: Фазовая коробка
  icon: "justdynathings:phase_box"
  position: 1
  parent: justdynathings:other.md
item_ids:
  - justdynathings:phase_box
---

# Фазовая коробка

_другое название — эфирное стекло_

Блок, у которого можно включать и выключать твёрдое состояние

Кроме того, он поддерживает связные текстуры (CTM), если установлен **Fusion** ~~ConnectedTexturesMod~~

<BlockImage id="justdynathings:phase_box" scale="4.0"/>

<Recipe id="justdynathings:phase_box" />

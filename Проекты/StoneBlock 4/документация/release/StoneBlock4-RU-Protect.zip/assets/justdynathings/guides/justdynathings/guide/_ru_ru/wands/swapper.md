---
navigation:
  title: Жезл обмена
  icon: "justdynathings:swapper_wand"
  position: 3
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:swapper_wand
---

# Жезл обмена

Жезл, который меняет блок местами с другим, не удаляя его из мира

<ItemImage id="justdynathings:swapper_wand" scale="4.0"/>

<Recipe id="justdynathings:swapper_wand" />

---
navigation:
  title: Продвинутый временной жезл
  icon: "justdynathings:advanced_time_wand"
  position: 1
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_time_wand
---

# Продвинутый временной жезл

Улучшенная версия <ItemLink id="justdirethings:time_wand"/>: увеличенная ёмкость и режимы настройки действия по клику

Режимы по умолчанию:

_можно изменить или отключить в конфиге!_

- Обычный:

Работает так же, как обычный <ItemLink id="justdirethings:time_wand"/>

- Скорость 2x:

Действие по клику срабатывает как 2x: 4 > 16 > 64 > 256

- Скорость 4x:

Действие по клику срабатывает как 4x: 16 > 256

- Максимальная скорость:

Действие по клику срабатывает как 8x, то есть всегда 256x

<ItemImage id="justdynathings:advanced_time_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_time_wand" />

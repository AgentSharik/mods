---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: МЭ расширенный интерфейс
    icon: extendedae:ex_interface
categories:
- extended devices
item_ids:
- extendedae:ex_interface
- extendedae:ex_interface_part
---

# МЭ расширенный интерфейс

<Row gap="20">
<BlockImage id="extendedae:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

МЭ расширенный интерфейс — <ItemLink id="ae2:interface" /> с большим инвентарём конфигурации.

*Это правда мне нужно?*

![ИнтерфейсРИ](../pic/ei_gui.png)

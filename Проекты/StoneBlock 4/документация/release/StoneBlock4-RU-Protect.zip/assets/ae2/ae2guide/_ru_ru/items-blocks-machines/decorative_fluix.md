---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Декоративный флюис
  icon: fluix_stairs
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_stairs
- ae2:fluix_wall
- ae2:fluix_slab
---

# Декоративный флюис

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/decorative_fluix.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Из блоков <ItemLink id="fluix_block" /> можно делать и вырезать в камнерезе некоторые декоративные строительные блоки.

## Рецепты

<Row>
  <RecipeFor id="fluix_stairs" />

  <RecipeFor id="fluix_wall" />

  <RecipeFor id="fluix_slab" />
</Row>

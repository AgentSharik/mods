import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import java.net.*;

/** Offline tests of the ACTUAL helper sources, with minimal Minecraft drawing/time stubs. */
public class RunLogicChecks {
    public static void main(String[] args) throws Exception {
        Path root=Path.of(args[0]), tmp=Files.createTempDirectory("angelring-qa-");
        Path util=tmp.resolve("net/minecraft/Util.java"), gui=tmp.resolve("net/minecraft/client/gui/GuiGraphics.java");
        Files.createDirectories(util.getParent()); Files.createDirectories(gui.getParent());
        Files.writeString(util,"package net.minecraft; public class Util { public static long getNanos() { return System.nanoTime(); } }");
        Files.writeString(gui,"package net.minecraft.client.gui; public class GuiGraphics { public void fill(int x,int y,int x2,int y2,int color) {} }");
        String test="""
import dev.agentsharik.angelring.RelicAbility;
import dev.agentsharik.angelring.client.ui.Ease;
import dev.agentsharik.angelring.client.ui.ParticlePool;
public class LogicChecks {
    static int checks;
    static void ok(boolean b,String why) { checks++; if(!b) throw new AssertionError(why); }
    static void near(float a,float b) { ok(Math.abs(a-b)<0.00005f,a+" != "+b); }
    public static void main(String[] args) {
        near(Ease.outCubic(0),0); near(Ease.outCubic(1),1);
        near(Ease.smoothStep(0),0); near(Ease.smoothStep(1),1);
        near(Ease.outBack(0),0); near(Ease.outBack(1),1);
        for(int fps:new int[]{30,60,144,240}) {
            float v=0;
            for(int frame=0;frame<fps;frame++) v=Ease.approach(v,1,1f/fps,6);
            near(v,1-(float)Math.exp(-6));
        }
        float prev=0;
        for(int i=0;i<=100;i++) { float v=Ease.smoothStep(i/100f); ok(v>=prev && v<=1,"monotone easing"); prev=v; }
        ParticlePool pool=new ParticlePool(128);
        for(int i=0;i<20;i++) pool.burstRect(0,0,62,20,100,0xC0394A,0xFF9B83);
        ok(pool.aliveCount()==128,"bounded particle pool");
        pool.update(2); ok(pool.aliveCount()==0,"particle expiration");
        pool.burstRect(0,0,12,12,14,1,2); ok(pool.aliveCount()==14,"pool reuse");
        pool.clear(); ok(pool.aliveCount()==0,"pool clear");
        for(int id=0;id<3;id++) {
            RelicAbility a=RelicAbility.byId(id); ok(a!=null && a.id==id,"ability lookup");
            for(int l=1;l<=4;l++) for(int s=0;s<6;s++) {
                if(a.active) {
                    ok(a.cooldownSeconds(s+1,l)<=a.cooldownSeconds(s,l),"rarity reduces cooldown");
                    ok(a.durationSeconds(s+1,l)>=a.durationSeconds(s,l),"rarity increases duration");
                    ok(a.radius(s+1)>=a.radius(s),"rarity increases radius");
                } else ok(RelicAbility.wardChance(s+1,l)>=RelicAbility.wardChance(s,l),"ward chance");
            }
        }
        ok(RelicAbility.byId(-1)==null && RelicAbility.byId(3)==null,"invalid ability id");
        near(RelicAbility.BONDS.radius(0),4); near(RelicAbility.BONDS.radius(6),8);
        near(RelicAbility.SANCTUARY.durationSeconds(6,1),10);
        ok(RelicAbility.wardChance(6,4)<=0.75f,"ward cap");
        System.out.println("PASS: "+checks+" isolated helper checks. Minecraft rendering/API integration NOT tested.");
    }
}
""";
        Path testPath=tmp.resolve("LogicChecks.java"); Files.writeString(testPath,test);
        List<java.io.File> sources=new ArrayList<>(); sources.add(util.toFile()); sources.add(gui.toFile()); sources.add(testPath.toFile());
        Path j=root.resolve("src/main/java/dev/agentsharik/angelring");
        for(String s:List.of("RelicAbility.java","client/ui/Ease.java","client/ui/ParticlePool.java")) sources.add(j.resolve(s).toFile());
        var compiler=ToolProvider.getSystemJavaCompiler();
        try(var fm=compiler.getStandardFileManager(null,null,null)) {
            boolean success=compiler.getTask(null,fm,null,List.of("--release","21","-d",tmp.toString()),null,fm.getJavaFileObjectsFromFiles(sources)).call();
            if(!success) System.exit(1);
        }
        try(var loader=new URLClassLoader(new URL[]{tmp.toUri().toURL()})) {
            loader.loadClass("LogicChecks").getMethod("main",String[].class).invoke(null,(Object)new String[0]);
        }
    }
}

from pathlib import Path
import json, re
from PIL import Image

root = Path(__file__).resolve().parents[1]
res = root / 'src/main/resources'
count = 0
for path in res.rglob('*'):
    if path.suffix in ('.json', '.mcmeta'):
        json.loads(path.read_text(encoding='utf-8'))
        count += 1
ru = json.loads((res/'assets/angelring/lang/ru_ru.json').read_text())
en = json.loads((res/'assets/angelring/lang/en_us.json').read_text())
assert ru.keys() == en.keys(), 'Translation key mismatch'
for key in ru:
    assert ru[key].count('%s') == en[key].count('%s'), key
for name, size in {'relic_ui':(512,256),'relic_fog':(512,384),'relic_haze':(512,384),'relic_haze_glow':(512,384),'ability_icons':(48,16),'rarity_stars':(16,8)}.items():
    path=res/f'assets/angelring/textures/gui/{name}.png'
    with Image.open(path) as im:
        assert im.size == size, (name, im.size)
        im.verify()
source = root/'src/main/java/dev/agentsharik/angelring'
screen = (source/'client/RelicScreen.java').read_text()
# Literal translation references (dynamic ability/stat/unit prefixes checked separately).
for key in re.findall(r'tr\("([a-z0-9_.]+)"', screen):
    if key.endswith('.'):
        continue
    assert 'gui.angelring.'+key in ru, key
for a in ['bonds','sanctuary','blood_ward']:
    for suffix in ['name','desc']:
        assert f'gui.angelring.ability.{a}.{suffix}' in ru
for key in ['duration','cooldown','radius','chance','heal']:
    assert f'gui.angelring.stat.{key}' in ru
for key in ['sec','blocks','percent','health']:
    assert f'gui.angelring.unit.{key}' in ru
for path in source.rglob('*.java'):
    text=path.read_text()
    assert not re.search(r'import\s+.*\.PlayerTickEvent;', text), path
    for literal in re.findall(r'Component.translatable\("([^"\n]+)"', text):
        if not literal.endswith('.'):
            assert literal in ru, (path.name, literal)
print(f'PASS: {count} JSON/metadata resources; {len(ru)} matching RU/EN keys; 6 texture dimensions; literal translation references; no PlayerTickEvent imports.')

import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;

public class ValidateSources {
    public static void main(String[] args) throws Exception {
        var compiler=ToolProvider.getSystemJavaCompiler();
        var diagnostics=new DiagnosticCollector<JavaFileObject>();
        try(var fm=compiler.getStandardFileManager(diagnostics,null,null); var walk=Files.walk(Path.of(args[0]))) {
            var files=walk.filter(p->p.toString().endsWith(".java")).map(Path::toFile).toList();
            var task=(JavacTask)compiler.getTask(null,fm,diagnostics,List.of("-proc:none","--release","21"),null,fm.getJavaFileObjectsFromFiles(files));
            int count=0;
            for(var unit:task.parse()) count++;
            for(var d:diagnostics.getDiagnostics()) System.out.println(d);
            long errors=diagnostics.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
            System.out.println("Java 21 syntax: "+count+" files; "+errors+" errors. Dependency/type checking NOT performed.");
            if(errors>0) System.exit(1);
        }
    }
}

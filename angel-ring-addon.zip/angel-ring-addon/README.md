# Кольцо ангела (Angel Ring) — аддон для NeoForge 1.21.1

Кольцо носится в слоте колец Curios. Пока оно надето, игрок летает как в творческом режиме
(двойное нажатие пробела). Если снять кольцо в воздухе, на 10 секунд включается мягкое падение.

## Прокачка и окно кольца (клавиша J)
- Кольцо получает опыт за полёт (5 очков опыта в секунду) и растёт до 10 уровня.
- За каждый новый уровень вы получаете 1 очко улучшений.
- Очки тратятся в окне кольца (клавиша J, меняется в настройках управления):
  - «Скорость» (до 5 рангов): +15% к скорости полёта за ранг;
  - «Мастерство» (до 5 рангов): +20% к набору опыта за ранг.
- Уровень и ранги хранятся в самом предмете (компонент `angelring:relic_data`).
- Окно: карточка кольца, описание, три характеристики (очки, опыт, бонус скорости), шкала опыта, два улучшения.
- Интерфейс и все картинки нарисованы заново и не заимствуют ресурсы других модов.

## Что внутри
- `src/main/java/dev/agentsharik/angelring/` — код (мод, предмет, полёт, прокачка, сеть, окно `client/`)
- `src/main/resources/assets/angelring/` — иконка (16x16), модель, переводы (en, ru), фон окна `textures/gui/relic_screen.png`
- `src/main/resources/data/angelring/recipe/` — рецепт: 4 пера, 4 золотых слитка, звезда Незера
- `src/main/resources/data/curios/tags/item/ring.json` — делает предмет «кольцом» для Curios
- `src/main/templates/META-INF/neoforge.mods.toml` — описание мода

## Как собрать (по шагам)
1. Установите JDK 21 и IntelliJ IDEA Community (оба бесплатные).
2. Скачайте официальный шаблон **NeoForge MDK для Minecraft 1.21.1** (ищите «NeoForge MDK 1.21.1» на neoforged.net) и распакуйте в пустую папку.
3. Удалите из шаблона пример кода: папку `src/main/java/com/example`.
4. Скопируйте папку `src` из этого архива в папку шаблона с заменой файлов.
   (Если у вашего шаблона файл `neoforge.mods.toml` лежит в `src/main/resources/META-INF/`, замените его там, а не в `templates`.)
5. В `gradle.properties` поменяйте:
       mod_id=angelring
       mod_name=Angel Ring
       mod_version=1.0.0
       mod_group_id=dev.agentsharik.angelring
       mod_authors=AgentSharik
6. В `build.gradle` добавьте репозиторий Curios (в блок `repositories { ... }`):
       maven { url = "https://maven.theillusivec4.top/" }
   и зависимости (в блок `dependencies { ... }`):
       compileOnly "top.theillusivec4.curios:curios-neoforge:9.5.0+1.21.1:api"
       runtimeOnly "top.theillusivec4.curios:curios-neoforge:9.5.0+1.21.1"
7. Откройте папку в IntelliJ как Gradle-проект, дождитесь загрузки, затем в терминале:
       ./gradlew runClient      (тестовый запуск игры)
       ./gradlew build          (готовый jar появится в build/libs)

## Как проверить в игре
- Дайте себе кольцо: `/give @s angelring:angel_ring` (или скрафтите).
- Откройте инвентарь, кнопка Curios, положите кольцо в слот колец.
- Дважды нажмите пробел — полёт включится. Снимите кольцо — полёт выключится.

## Для игры с готовым jar
Положите в `mods`: jar этого аддона + Curios API (curios-neoforge 1.21.1) + ваш Fallen Relics.

## Если что-то не собирается
Скопируйте полный текст ошибки и пришлите мне. Код написан без возможности скомпилировать его
на моей стороне, поэтому мелкие правки (имена методов Curios и т. п.) возможны.

package dev.agentsharik.angelring;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

/**
 * Аддон «Кольцо ангела». Само кольцо носится в слоте аксессуаров Curios (слот "ring").
 */
@Mod(AngelRingMod.MOD_ID)
public class AngelRingMod {
    public static final String MOD_ID = "angelring";

    public AngelRingMod(IEventBus modEventBus) {
        ModItems.ITEMS.register(modEventBus);
        modEventBus.addListener(ModItems::addToCreativeTab);
    }
}
